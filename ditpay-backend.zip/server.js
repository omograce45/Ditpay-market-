import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import db from "./db.js";

dotenv.config();
const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static assets (css/images if any)
app.use('/static', express.static(path.join(__dirname, 'views', 'static')));

// Serve simple admin and index pages
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'admin.html'));
});

// Initialize the posts table if it doesn't exist
async function ensureTable() {
  const createSql = `
    CREATE TABLE IF NOT EXISTS posts (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      price VARCHAR(100) NOT NULL,
      image TEXT,
      description TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB;
  `;
  try {
    await db.execute(createSql);
    console.log('✅ posts table ensured');
  } catch (err) {
    console.error('❌ Error ensuring table:', err.message);
  }
}

// Create new post
app.post('/api/posts', async (req, res) => {
  const { title, price, image, description } = req.body;
  if (!title || !price) return res.status(400).json({ error: 'Title and price required' });

  try {
    const sql = 'INSERT INTO posts (title, price, image, description) VALUES (?, ?, ?, ?)';
    const [result] = await db.execute(sql, [title, price, image || '', description || '']);
    res.status(201).json({ message: 'Post created', id: result.insertId });
  } catch (err) {
    console.error('Error creating post:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Get all posts
app.get('/api/posts', async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM posts ORDER BY created_at DESC');
    res.json(rows);
  } catch (err) {
    console.error('Error fetching posts:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Start server after ensuring table
const PORT = process.env.PORT || 5000;
ensureTable().then(() => {
  app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
});
